interface IConstants {
	// WhatsApp status broadcast
	statusBroadcast: string;
}

const constants: IConstants = {
	statusBroadcast: "status@broadcast"
};

export default constants;
